/*
 * Tab3.h
 *
 *  Created on: 12 mar 2016
 *      Author: pawel
 */

#ifndef TAB3_H_
#define TAB3_H_

class Tab3 {
private:
	int rozmiar;
public:
int *tab1;
int *tab2;
Tab3();
~Tab3();

void wypelnijtab();
//void wypisz();

};

#endif /* TAB3_H_ */
