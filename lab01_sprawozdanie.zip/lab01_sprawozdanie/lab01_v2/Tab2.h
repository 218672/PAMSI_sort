/*
 * Tab2.h
 *
 *  Created on: 12 mar 2016
 *      Author: pawel
 */

#ifndef TAB2_H_
#define TAB2_H_

class Tab_2 {
private:
	int rozmiar;
public:
	int *tab1;
	int *tab2;
	Tab_2();
	~Tab_2();
	void wypelnijtab();
	//void wypisz();
};

#endif /* TAB2_H_ */
