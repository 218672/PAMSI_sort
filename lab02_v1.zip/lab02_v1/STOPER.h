/*
 * STOPER.h
 *
 *  Created on: 18 mar 2016
 *      Author: pawel
 */
#include <ctime>
#ifndef STOPER_H_
#define STOPER_H_

class STOPER {
private:

	clock_t czas1;
	clock_t czas2;
	public:
void start();
void stop();
void wyswietl();

	STOPER();
	~STOPER();

};

#endif /* STOPER_H_ */
