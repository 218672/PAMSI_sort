/*
 * stos.cpp
 *
 *  Created on: 1 kwi 2016
 *      Author: pj
 */

#include "stos.h"
#include <iostream>

using namespace std;

void stos::push(int element)
{

this->add(element,0);

}


int stos::pop()
{

	int t=this->get(0);
this->remove(0);

return t;
}


int stos::size()
{

	return this->size();


}
