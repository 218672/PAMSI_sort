/*
 * Ikolejka.h
 *
 *  Created on: 1 kwi 2016
 *      Author: pj
 */

#ifndef IKOLEJKA_H_
#define IKOLEJKA_H_

class Ikolejka: public Ilist
{
public:/*
	virtual void push(int element);
	virtual int pop();
	virtual int size();

*/

};




#endif /* IKOLEJKA_H_ */
