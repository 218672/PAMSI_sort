

#ifndef STOS_H_
#define STOS_H_

class stos:public Istos{
public:
	void push(int element);
	int pop();
	int size();

};




#endif /* STOS_H_ */
