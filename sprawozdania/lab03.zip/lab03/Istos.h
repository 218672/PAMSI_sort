/*
 * Istos.h
 *
 *  Created on: 1 kwi 2016
 *      Author: pj
 */

#ifndef ISTOS_H_
#define ISTOS_H_

class Istos: public Ilist{
public:

	virtual void push(int element)=0;;
	virtual int pop()=0;
	virtual int size()=0;


};


#endif /* ISTOS_H_ */
