/*
 * Ilist.h
 *
 *  Created on: 1 kwi 2016
 *      Author: pj
 */

#ifndef ILIST_H_
#define ILIST_H_

class Ilist{
public:
	virtual int add(int element,int position)=0;
	virtual void remove(int position )=0;
	virtual int get(int position)=0;
	virtual int size()=0;

};



#endif /* ILIST_H_ */
