/*
 * main.cpp
 *
 *  Created on: 1 kwi 2016
 *      Author: pj
 */


#include "stos.h"
#include "Istos.h"
#include "Ikolejka.h"
#include "Ilist.h"
#include <iostream>




using namespace std;


int main(){


return 0;
}
