
#include <ctime>
#ifndef STOPER_H_
#define STOPER_H_

class STOPER {
private:
	clock_t czas1;
	clock_t czas2;
	public:
void start();
void stop();
void wyswietl();

	STOPER();
	~STOPER();

};

#endif /* STOPER_H_ */
