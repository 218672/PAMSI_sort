#include "tab_d.h"
#include "stoper.h"
#include "interface.h"


#include <iostream>

using namespace std;

int main(){
	STOPER t;
Tab3 tablica;

t.start();
tablica.wypelnijtab1();
t.stop();
t.wyswietl();
/*
t.start();
tablica.wypelnijtab2();
t.stop();
t.wyswietl();

t.start();
tablica.wypelnijtab3();
t.stop();
t.wyswietl();

*/

//tablica.wypisz();

cout<<endl;

	return 0;
}
