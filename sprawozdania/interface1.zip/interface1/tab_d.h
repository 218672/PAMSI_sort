
#ifndef TAB_D_H_
#define TAB_D_H_




class Tab3/*:public Interface*/{

private:
	int rozmiar;
public:
int *tab1;
int *tab2;

void wypelnijtab1();
//void wypelnijtab2();
//void wypelnijtab3();
//void wypisz();

Tab3();
~Tab3();
};



#endif /* TAB_D_H_ */
