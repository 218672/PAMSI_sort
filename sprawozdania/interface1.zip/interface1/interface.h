


#ifndef INTERFACE_H_
#define INTERFACE_H_

class Interface{
public:

	virtual void wypelnijtab1()=0;
	//virtual void wypelnijtab2()=0;
	//virtual void wypelnijtab3()=0;

	//virtual void przygotuj();
	//virtual void wykonaj();


	//virtual void start()=0;
	//virtual void stop()=0;
	//virtual void wyswietl()=0;


};


#endif /* INTERFACE_H_ */
