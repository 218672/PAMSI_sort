
#include "stoper.h"
#include <iostream>

using namespace std;

STOPER::STOPER() {
	czas1=0;
	czas2=0;
	cout<<"zaczynam za chwile"<<endl;
}

STOPER::~STOPER() {

}

void STOPER::start(){

czas1=clock();

}

void STOPER::stop(){

	czas2=clock();

}

void STOPER::wyswietl(){

cout.setf(ios::fixed);
	cout<<"juz policzylem: "<<double(czas2-czas1)/CLOCKS_PER_SEC<<" sekund" <<endl;

}


